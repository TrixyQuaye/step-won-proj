<?php
    

    $db = mysqli_connect("localhost", "ransford_nyarko", "ransford_nyarko", "webtech_fall2019_ransford_nyarko");

        // CHECKING FOR PASSWORDS
    if (isset($_POST['submit'])) {
        session_start();
        $password = mysqli_real_escape_string($db, $_POST['passw']);
        $cpassword = mysqli_real_escape_string($db,$_POST['cpassw']);
        $fname = mysqli_real_escape_string($db,$_POST['first_nam']);
        $lname = mysqli_real_escape_string($db,$_POST['last_nam']);
        $email = mysqli_real_escape_string($db,$_POST['emai']);
        $phone = mysqli_real_escape_string($db,$_POST['phone_number']);
        $category = $_POST['mem'];
        $client = mysqli_real_escape_string($db,$_POST['radio']);
        $shop = mysqli_real_escape_string($db,$_POST['nos']);
        $categoryshop = mysqli_real_escape_string($db,$_POST['Category']);
        # code...
    
        if ($password  === $cpassword) {
            if ($email == "" || $fname == "" || $lname == "" || $phone== "" || $cpassword == "" || $password == "" ||$client == "") {
                header("location: signup.php");

            }
            $password = password_hash($password, PASSWORD_DEFAULT);
            $sql = "INSERT INTO user (firstname, lastname, phoneNumber, Password, Email, Category, ClientType, NameofShop, CategoryofShop) VALUES ('$fname', '$lname', '$phone', '$password', '$email','$category','$client ', '$shop','$categoryshop')";
            mysqli_query($db, $sql);
            if ( $client === "Vendor") {
            $_SESSION['uname'] = $fname;
            $_SESSION['client'] = $client;
            $_SESSION['message'] = "You are now logged in";
            header("location: login.php");
            # code...
            }
            elseif ( $client === "Shopper") {
                header("location: login.php");
                $_SESSION['client'] = $client;
                # code...
            }

                
        else{
            $_SESSION['message'] = "The two passwords do not match";
        }
            
        }

    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sign Up Form by Colorlib</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="vendor/nouislider/nouislider.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="css/signup.css">
</head>
<body>

    <div class="main">

        <div class="container">
           <!--  <div class="signup-content"> -->
                <div class="signup-form">
                    <form method="post" action="signup.php" class="register-form" id="register-form">
                        <div class="form-row">
                            <div class="form-group">
                                <div class="form-input">
                                    <label for="first_name" class="required">First name</label>
                                    <input type="text" name="first_nam" id="first_name" />
                                </div>
                                <div class="form-input">
                                    <label for="last_name" class="required">Last name</label>
                                    <input type="text" name="last_nam" id="last_name" />
                                </div>
                                <div class="form-input">
                                    <label for="p" class="required">Password</label>
                                    <input type="password" name="passw" id="pass" />
                                </div>
                                <div class="form-input">
                                    <label for="cpass" class="required">Confirm Password</label>
                                    <input type="Password" name="cpassw" id="cpass" />
                                </div>
                                <div class="form-input">
                                    <label for="email" class="required" data-validate = "Enter email">Email</label>
                                    <input type="text" name="emai" id="email" />
                                </div>
                                <div class="form-input">
                                    <label for="phone_number" class="required">Phone number</label>
                                    <input type="text" name="phone_number" id="phone_number" />
                                </div>
                                <p class="mt-5" style="color: black; margin-top: 20px;">Already have an Account? <span><a href="login.php" id="accLink">Login</a></span></p>
                            </div>
                            <div class="form-group">
                                <div class="form-select">
                                    <div class="label-flex">
                                        <label for="mem">Where do you Fall</label>
                                    </div>
                                    <div class="select-list">
                                        <select name="mem" id=>
                                            <option value="0">Choose an option</option>
                                            <option value="Student">Student</option>
                                             <option value="Staff/Faculty">Staff/Faculty</option>
                                            <option name="mem" value="Outside Ashesi">Outside Ashesi</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-radio">
                                    <div class="label-flex">
                                        <label for="payment">Client Type</label>
                                    </div>
                                    <div class="form-radio-group">            
                                        <div class="form-radio-item">
                                            <input type="radio" name="radio" id="vendor" value= "Vendor" >
                                            <label for="vendor">Vendor</label>
                                            <span class="check"></span>
                                        </div>
                                        <div class="form-radio-item">
                                            <input type="radio" name="radio" id="Shopper" value="Shopper">
                                            <label for="Shopper">Shopper</label>
                                            <span class="check"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-input">
                                    <label for="nos">Name of Shop</label>
                                    <input type="text" name="nos" id="Category" />
                                </div>
                                <div class="form-input">
                                    <label for="Category">Category of Shop</label>
                                    <input type="text" name="Category" id="Category" />
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-submit">
                            <input type="submit" value="Submit" class="submit" id="submit" name="submit" />
                            <input type="submit" value="Reset" class="submit" id="reset" name="reset" />
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>

    <!-- JS -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/nouislider/nouislider.min.js"></script>
    <script src="vendor/wnumb/wNumb.js"></script>
    <script src="vendor/jquery-validation/dist/jquery.validate.min.js"></script>
    <script src="vendor/jquery-validation/dist/additional-methods.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>