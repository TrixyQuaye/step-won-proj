-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 20, 2019 at 10:48 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aos2`
--

-- --------------------------------------------------------

-- USE webtech_fall2019_ransford_nyarko;
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(10) NOT NULL,
  `product` varchar(25) NOT NULL,
  `price` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `product`, `price`, `quantity`) VALUES
(51432039, '0', 55, 1),
(51432039, '0', 55, 1),
(51432039, 'Indian Cloth', 55, 1);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `uid` int(10) NOT NULL,
  `image` text NOT NULL,
  `productName` varchar(25) NOT NULL,
  `price` text NOT NULL,
  `productDesc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`uid`, `image`, `productName`, `price`, `productDesc`) VALUES
(51432039, 'images.jpg', 'Indian Cloth', '55', 'kdkd');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userId` int(10) NOT NULL,
  `firstname` varchar(25) NOT NULL,
  `lastname` varchar(25) DEFAULT NULL,
  `phoneNumber` text DEFAULT NULL,
  `Password` varchar(25) NOT NULL,
  `Email` varchar(225) NOT NULL,
  `Category` enum('Student','Staff/Faculty','','') NOT NULL,
  `ClientType` enum('Vendor','Shopper','','') NOT NULL,
  `NameofShop` varchar(225) DEFAULT NULL,
  `CategoryofShop` varchar(225) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userId`, `firstname`, `lastname`, `phoneNumber`, `Password`, `Email`, `Category`, `ClientType`, `NameofShop`, `CategoryofShop`) VALUES
(51432021, 'Najahat', 'Antiku', '241268003', '0', '', 'Student', 'Vendor', '', ''),
(51432022, '', '', '0022', 'd41d8cd98f00b204e9800998e', '', '', '', '', ''),
(51432023, '', '', '0022', 'd41d8cd98f00b204e9800998e', '', '', '', '', ''),
(51432024, '', '', '022', 'd41d8cd98f00b204e9800998e', '', '', '', '', ''),
(51432025, '', '', '022', 'd41d8cd98f00b204e9800998e', '', '', '', '', ''),
(51432026, 'R', 'N', '022', '0cc175b9c0f1b6a831c399e26', 'rna', '', '', '', ''),
(51432028, 'Godlve', 'Otoo', '02445', '0cc175b9c0f1b6a831c399e26', 'gottoo', '', '', 'Foodine', 'food'),
(51432030, 'Ransford', 'Nyarko', '0022', '4015e9ce43edfb0668ddaa973', 'rna', 'Student', 'Vendor', 'Milky Mt', 'Food'),
(51432032, 'Ransford', 'Nyarko', '0022', '4015e9ce43edfb0668ddaa973', 'rna', 'Student', 'Shopper', 'Afrikiko', 'Food'),
(51432035, 'a', 'B', '0022', '8a8bb7cd343aa2ad99b7d7620', 'rna', 'Student', 'Shopper', 'CLothen', 'Food'),
(51432036, 'Trixy', 'Quaye', '0022', '8a8bb7cd343aa2ad99b7d7620', 'tri@gmail.com', 'Student', 'Shopper', 'CLothen', 'Clothes'),
(51432037, 'Ransford', 'Nyarko', '055', '0cc175b9c0f1b6a831c399e26', 'ransford@gmail.com', 'Student', 'Shopper', 'CLothen', 'Food'),
(51432038, 'Ransford', 'Nyarko', '0022', '$argon2i$v=19$m=65536,t=4', 'ny@gmail.com', 'Student', 'Shopper', 'CLothen', 'Food'),
(51432039, 'ny', 'N', '0022', '$argon2i$v=19$m=65536,t=4', 'or@gmail.com', 'Student', 'Vendor', 'CLothen', 'Food'),
(51432040, '', '', '', '$argon2i$v=19$m=65536,t=4', 'rna', '', '', '', ''),
(51432041, '', '', '0022', '$argon2i$v=19$m=65536,t=4', '', '', '', '', ''),
(51432042, '', '', '', '$argon2i$v=19$m=65536,t=4', '', '', '', '', ''),
(51432043, '', '', '0022', '$argon2i$v=19$m=65536,t=4', '', '', '', '', ''),
(51432044, 'Ransford', '', '', '$argon2i$v=19$m=65536,t=4', '', '', 'Vendor', '', ''),
(51432045, '', '', '', '$argon2i$v=19$m=65536,t=4', '', '', '', '', ''),
(51432046, '', '', '', '$argon2i$v=19$m=65536,t=4', '', '', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD KEY `id` (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD KEY `uid` (`uid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `userId` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51432047;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`id`) REFERENCES `user` (`UserId`);

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `user` (`UserId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
