<?php

	$db = mysqli_connect("localhost", "ransford_nyarko", "ransford_nyarko", "webtech_fall2019_ransford_nyarko");

	if (isset($_POST['login'])) {
		$password = mysqli_real_escape_string($db, $_POST['pass']);
		$email = mysqli_real_escape_string($db,$_POST['email']);
		$pass = password_hash($password, PASSWORD_DEFAULT);

		$sql = "SELECT userId, firstname, Password, Email, ClientType FROM  user WHERE Email = '$email'";
		$result = mysqli_query($db, $sql);


		if ($result->num_rows > 0){
			while($row = $result->fetch_assoc()) {
				if ($email == $row['Email'] and password_verify($password, $pass)) {
					session_start();
					$_SESSION['uname'] = $row ['firstname'];
					$_SESSION['client'] = $row['ClientType'];
					$_SESSION['id'] = $row['userId'];
					if ($row['ClientType'] =="Shopper") {
						header("location: index.php");
					}
					else{
						header("location: dashboard.php");

					}
					
				}
				else{
					header("location: signup.php");
				}
    }
		}


	}

?>


<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>

	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">

	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">

	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">

	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">

	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">

	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">

	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">

</head>
<body>
	
	<div class="limiter">
		<div class="container-login100" style="background-image: url('https://images.pexels.com/photos/972995/pexels-photo-972995.jpeg?auto=compress&cs=tinysrgb&dpr=3&h=750&w=1260');">
			<div class="wrap-login100">
				<form class="login100-form validate-form" method="post">
					<span class="login100-form-logo">
						<img src="images/AOS.png" style="width: 80px; height: 80px">
					</span>

					<span class="login100-form-title p-b-34 p-t-27">
						Log in
					</span>

					<div class="wrap-input100 validate-input" data-validate = "Enter email">
						<input class="input100" type="text" name="email" placeholder="Email">
						<i class="focus-input100" data-placeholder="&#xf207;"></i>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Enter password">
						<input class="input100" type="password" name="pass" placeholder="Password">
						<i class="focus-input100" data-placeholder="&#xf191;"></i>
					</div>

					<div class="contact100-form-checkbox">
						<input class="input-checkbox100" id="ckb1" type="checkbox" name="remember-me">
						<label class="label-checkbox100" for="ckb1">
							Remember me
						</label>

					</div>

					<div class="container-login100-form-btn">
						<button class="login100-form-btn" name="login">
							Login
						</button>
					</div>

					<div class="text-center p-t-10">
						or
						<a class="txt1 d-block" href="signup.php">
							Sign Up Here
						</a>
					</div>
				</form>
			</div>
		</div>
	</div>
	

	<div id="dropDownSelect1"></div>
	
<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main2.js"></script>
	<script src="https://kit.fontawesome.com/97e0072cbb.js" crossorigin="anonymous"></script>
</body>
</html>