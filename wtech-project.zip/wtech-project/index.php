<?php
	session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Home</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/style2.css">
    <link rel="stylesheet" href="css/button.css">
  </head>
  <body class="goto-here">
		<div class="py-1 bg-light">
    	<div class="container">
    		 <div class="top-bar py-3 bg-light" id="home-section">
      <div class="container">
        <div class="row align-items-center">
         
          <div class="col-6 text-left" >
          	<div class="col-md-5 pr-4 d-flex topper align-items-center text-lg-right">
          		<?php
          		if (isset($_SESSION['uname'])) {
          			echo"<span class='text' style='color: black;font-size = 100px;'> Welcome " .$_SESSION['uname']."</span>";
          		}
          		else{
          		echo "<span class='text' style='color: black;'>3-5 Business days delivery ; Free Returns</span>";
          	}
          		?>
			</div>
          </div>
          <div class="col-6">
            <p class="mb-0 float-right">
            <?php
            	if (isset($_SESSION['uname'])) {
            		echo "<span class='mr-3'><a href='logout.php'> <span style='position: relative; top: 12px;'><i class='fas fa-door-open m-2'></i></span><span class='d-none d-lg-inline-block text-black' style='position: relative; top: 12px;'>Logout</span></a></span>";
            	}
            	else{
	              echo "<span class='mr-3'><a href='login.php'> <span style='position: relative; top: 12px;'><i class='fas fa-user-plus m-2'></i></span><span class='d-none d-lg-inline-block text-black' style='position: relative; top: 12px;'>Login</span></a></span>";
	              echo "<span><a href='signup.php'><span class='mr-0' style='position: relative; top: 12px;'><i class='fas fa-users m-2'></i></span><span class='d-none d-lg-inline-block text-black mr-3 px-0' style='position: relative; top: 12px;'>Sign Up</span></a></span>";
	          }
              ?>
              <span style="position: relative; top: 2px;" class="search-box d-flex justify-content-end m-2">
                <input type="" name="" placeholder="Enter Keyword" class="search-txt">
                  <a class="search-btn" href="#">
                    <i class="fa fa-search"></i>
                  </a>      
             </span>
            </p>
            
          </div>
        </div>
      </div> 
    </div>
		    </div>
		  </div>
    </div>
    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-dark" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="index.html">aos</a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item active"><a href="index.html" class="nav-link">Home</a></li>
	          <li class="nav-item">
              <a class="nav-link" href="shop.php">Shop</a>     
            </li>
	          <li class="nav-item"><a href="#about-us" class="nav-link">About</a></li>
	          <?php

	          if (isset($_SESSION['uname'])) {
		          if ($_SESSION['client'] == "Vendor") {
		          	echo "<li class='nav-item'><a href='dashboard.php' class='nav-link'>Dashboard</a></li>";
	          	}
	          }

	          
	          ?>
	          <li class="nav-item"><a href="#contactUs" class="nav-link">Contact</a></li>
	          <li class="nav-item cta cta-colored"><a href="cart.html" class="nav-link"><span class="icon-shopping_cart"></span>[0]</a></li>

	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->

    <section id="home-section" class="hero">
		  <div class="home-slider js-fullheight owl-carousel">
	      <div class="slider-item js-fullheight">
	      	<div class="overlay"></div>
	        <div class="container-fluid p-0">
	          <div class="row d-md-flex no-gutters slider-text js-fullheight align-items-center justify-content-end" data-scrollax-parent="true">
	          	<div class="one-third order-md-last img js-fullheight" style="background-image:url(images/adepa1.png);">
	          	</div>
		          <div class="one-forth d-flex js-fullheight align-items-center ftco-animate" data-scrollax=" properties: { translateY: '70%' }">
		          	<div class="text">
		          		<span class="subheading">Ashesi Online Shop</span>
		          		<div class="horizontal">
		          			<h3 class="vr" style="background-image: url(images/divider.jpg);">Stablished Since 2000</h3>
				            <h1 class="mb-4 mt-3">Adepa BreakFast </h1>
				            <p>Enjoy the our latest addition to the AOS Family.Here at AOS we have joint values the Adepa service we aim to serve</p>
				            
				            <p><a href="#" class="btn btn-primary px-5 py-3 mt-3">Discover Now</a></p>
				          </div>
		            </div>
		          </div>
	        	</div>
	        </div>
	      </div>

	      <div class="slider-item js-fullheight">
	      	<div class="overlay"></div>
	        <div class="container-fluid p-0">
	          <div class="row d-flex no-gutters slider-text js-fullheight align-items-center justify-content-end" data-scrollax-parent="true">
	          	<div class="one-third order-md-last img js-fullheight" style="background-image:url(images/cupcake.png);">
	          	</div>
		          <div class="one-forth d-flex js-fullheight align-items-center ftco-animate" data-scrollax=" properties: { translateY: '70%' }">
		          	<div class="text">
		          		<span class="subheading">Winkel eCommerce Shop</span>
		          		<div class="horizontal">
		          			<h3 class="vr" style="background-image: url();">Ashesi Online Shop</h3>
				            <h1 class="mb-4 mt-3">For the Startups</h1>
				            <p>For Buzzing new companies looking to make a head start AOS is the perfect place to begin</p>
				            
				            <p><a href="#" class="btn btn-primary px-5 py-3 mt-3">Shop Now</a></p>
				          </div>
		            </div>
		          </div>
	        	</div>
	        </div>
	      </div>
	    </div>
    </section>




    <section class="ftco-section bg-light" id="about-us">
    	<div class="container">
    		<div class="row justify-content-center mb-3 pb-3">

		        <div class="text-center mt-2 pt-2 ftco-animate">
		      	<h1 class= "info">Our vision is to provide one of the best customer exeperience<br>
		      	for both client shops and our lovely shoppers;</h1>
		      	<p class="info">we achieve this with an algorithm design like no other, providing
		      	client shops analytical feedback<br> and giving our shoppers the best suggestions according to their taste.</p>
		      	<h3 class="info">Where do you fall between?</h3>
      	
      </div>


      <section class="d-flex justify-content-center ftco-animate" >
      		<a href="" class="capt"><div class="m-5" style="width: 18rem;" data-aos="fade" data-aos-delay="100">
      			<img src="https://images.pexels.com/photos/291762/pexels-photo-291762.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="..." class="card-img-top">
      			<div class="car">
	    			<h3 class="">Shopper</h3>
	  			</div>
			</div></a>

			<a href="" class="capt"><div class="m-5" style="width: 18rem;" data-aos="fade" data-aos-delay="300">
	  			<img src="https://images.pexels.com/photos/1181435/pexels-photo-1181435.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" class="card-img-top" alt="...">
	  			<div class="">
	    			<h3 class="">Client Shop</h3>
	  			</div>
			</div></a>
      </section>

        </div>   		
    	</div>
    	

    <section class="ftco-section ftco-choose ftco-no-pb ftco-no-pt">
	    <div class="site-section border-bottom" id="team-section">
	      <div class="container">
	        <div class="row mb-5">
	          <div class="col-12 text-center">
	            <h3 class="section-sub-title">Team</h3>
	            <h2 class="section-title mb-3">Leadership</h2>
	          </div>
	        </div>
	        <div class="row">
	          <div class="col-md-6 col-lg-3 mb-5 mb-lg-0" data-aos="fade" data-aos-delay="100">
	            <div class="person text-center">
	              <img src="https://images.pexels.com/photos/1181435/pexels-photo-1181435.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="Image" class="img-fluid rounded w-75 mb-3" style="height: 200px;">
	              <h3>Trixy Quaye</h3>
	              <p class="position text-muted">Back-End, Designer</p>
	              <p class="mb-4">In ‘The Composition’, I am responsible for server side programming i.e handling the business logic of the online store. I am quite conversant with Python and PHP languages, the latter which I am implementing in the Ashesi Online Store project..</p>
	            </div>
	          </div>
	          <div class="col-md-6 col-lg-3 mb-5 mb-lg-0" data-aos="fade" data-aos-delay="200">
	            <div class="person text-center">
	              <img src="https://thecompositionteam.files.wordpress.com/2019/09/download.png" alt="Image" class="img-fluid rounded w-75 mb-3" style="height: 200px;">
	              <h3>Ransford Nyarko</h3>
	              <p class="position text-muted">Data Analyst</p>
	              <p class="mb-4">Ransford Nyarko is a student majoring in Computer Science. He initially planned to become back-end developer, but as fate would have it he is pursuing a career in front-end design and development.</p>
	            </div>
	          </div>
	          <div class="col-md-6 col-lg-3 mb-5 mb-lg-0" data-aos="fade" data-aos-delay="300">
	            <div class="person text-center">
	              <img src="https://thecompositionteam.files.wordpress.com/2019/09/img_3992-e1569689946572.jpg" alt="Image" class="img-fluid rounded w-75 mb-3" style="height: 200px;">
	              <h3>Oluwafikunmi Falase</h3>
	              <p class="position text-muted">System Architecture</p>
	              <p class="mb-4">Oluwafikunmi Oluwamayowa is a 3rd year Management and information systems student in Ashesi university. She initially started out studying Computer science but soon realized she also enjoyed business courses and decided to make a switch that gave her the perfect blend of business and technology.</p>
	            </div>
	          </div>
	          <div class="col-md-6 col-lg-3 mb-5 mb-lg-0" data-aos="fade" data-aos-delay="100">
	            <div class="person text-center">
	              <img src="https://thecompositionteam.files.wordpress.com/2019/09/najahat-.jpeg?w=768" alt="Image" class="img-fluid rounded w-75 mb-3" style="height: 200px;">
	              <h3>Najahat Antiku</h3>
	              <p class="position text-muted">Co-Founder, President</p>
	              <p class="mb-4">Najahat Antiku is a young technology enthusiast reading Management Information Systems at Ashesi University. She is interested in using technology to solve business issues. She spends much of her time using SQL to create database systems and mimicking front-end views of websites. .</p>
	            </div>
	          </div>

	        </div>
	      </div>
	    </div>
    </section>


	
    <footer class="ftco-footer bg-light ftco-section" id="contactUs">
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
            	<h1 class="ftco-heading-2 text-center">Contact Us</h1>
            	<h2 class="ftco-heading-2 text-center">Have a Questions?</h2>
            	<div class="block-23 mb-3">
	              <ul>
	                <li><span class="icon icon-map-marker"></span><span class="text"> Ashesi University. Est. 2002,  PMB CT3,
						Cantonments, Accra.</span></li>
	                <li><a href="#"><span class="icon icon-phone"></span><span class="text">+2 392 3929 210</span></a></li>
	                <li><a href="#"><span class="icon icon-envelope"></span><span class="text">aos@ashesi.edu.gh</span></a></li>
	              </ul>
	            </div>
            </div>
          </div>
        </div>
        



  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
  <script src="https://kit.fontawesome.com/97e0072cbb.js" crossorigin="anonymous"></script>
    
  </body>
</html>