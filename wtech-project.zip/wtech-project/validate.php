<?php
	session_start();
	print_r($_POST);
	$a = (array_values($_POST));
	$_SESSION['cart'] = $a[0];
	
?>