<?php
  // Create database connection
  $db = mysqli_connect("localhost", "ransford_nyarko", "ransford_nyarko", "webtech_fall2019_ransford_nyarko");
  session_start();
  $id = $_SESSION['id'];
  // Initialize message variable
  $msg = "";
  // If upload button is clicked ...
  if (isset($_POST['upload'])) {
    // Get image name
    $image = $_FILES['file']['name'];
    // Get text
    $price = mysqli_real_escape_string($db, $_POST['price']);
    $prod_name = mysqli_real_escape_string($db, $_POST['prod_name']);
    $prod_desc = mysqli_real_escape_string($db, $_POST['prod_desc']);
    

    // image file directory
    $target = "images/".basename($image);

    $sql = "INSERT INTO product (uid, image, productName, price, productDesc) VALUES ('$id', '$image', '$prod_name', '$price','$prod_desc')";
    
    // execute query
    mysqli_query($db, $sql); 

    if (move_uploaded_file($_FILES['file']['tmp_name'], $target)) {
      $msg = "Image uploaded successfully";
      header("location: shop.php");
    }else{
      $msg = "Failed to upload image";
    }
    
  }
  $result = mysqli_query($db, "SELECT * FROM images");
?>



<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="dashboard.css">

    <title>Post</title>
  </head>
  <body>
   <nav class=" navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
      <a class="navbar-brand ml-5 pl-5" href="#">AOS</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="#">Dashboard<span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="index.php">Home</a>
          </li>
        </ul>
      </div>
        <form class="form-inline my-2 my-lg-0">
          
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="#">Welcome User</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="logout.php">Logout</a>
            </li>
          </ul>
        </form>
      </div>
    </nav>

    <header id="header">
      <div class="container">
        <div class="row">
          <div class="col-md-10">
            <h1><i class="fas fa-user-cog mr-4"></i>Dashboard <small>Manage Your Site</small></h1> 
          </div>

          <div class="col-md-2">
            <div class="dropdown create">
              <button class="btn btn-primary" type="button" data-toggle="modal" data-target="add-page">Post Product</button>
              
            </div>
            
          </div>
          
        </div>
        
      </div>
    </header>

    <section id="breadcrumb">
      <div class="container">
        <ol class="breadcrumb">
          <li class="active">Dashboard</li>
        </ol>
        
      </div>
      
    </section>

    <section id="main">
      <div class="container">
        <div class="row">
          <div class="col-md-3">
            <div class="list-group">
                <a href="dashboard.php" class="list-group-item list-group-item-action">
                  <i class="fas fa-cog mr-4"></i>Dashboard
                </a>
                <a href="#" class="list-group-item list-group-item-action active bg-dark"><i class="fas fa-pencil-alt mr-4" data-toggle="modal" data-target="#myModal"></i>Post<span class="badge ml-2">33</span></a>
                <a href="order.php" class="list-group-item list-group-item-action"><i class="fas fa-truck mr-4"></i>Orders<span class="badge ml-2">111</span></a>
              </div>   
          </div>

           <div class="col-md-9">
            <form method="POST" enctype="multipart/form-data">
             <div>
              <label>Enter Image here</label>
              <input type="file" name="file" id="real-file" hidden="hidden">
              <input type="button" id="custom-button" value="Choose A File">
              <span id="custom-text"> No file Chosen</span>
            </div>
             <div class="form-group">
              <label>Product Name</label>
              <input type="text" name="prod_name" class="form-control" placeholder="Enter Product Name">
            </div>
            <div class="form-group">
              <label>Price</label>
              <input type="number" name="price" class="form-control" placeholder="Enter Product Name">
            </div>
            <div class="form-group">
              <label>Product Description</label>
              <textarea id="text"cols="40" rows="4"name="prod_desc"  class="form-control" placeholder="Enter Product Description"></textarea>
            </div>
            <button type="submit" name="upload">POST</button>
          </form>
             
           </div>
          </div>
        </div>
      </div> 
    </section>



    

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://kit.fontawesome.com/97e0072cbb.js" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="choose.js"type="text/javascript"></script>
  </body>
</html>