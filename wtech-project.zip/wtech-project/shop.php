<?php
	session_start();
  // Create database connection
  $db = mysqli_connect("localhost", "ransford_nyarko", "ransford_nyarko", "webtech_fall2019_ransford_nyarko");
  $result = mysqli_query($db, "SELECT * FROM product");
  


?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Winkel - Free Bootstrap 4 Template by Colorlib</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css"> 
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="shopsty.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet">
  </head>
  <body class="goto-here">

    <nav class="navbar navbar-expand-lg navbar-light ftco_navbar bg-dark ftco-navbar-dark" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="index.html">AOS</a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
	          <li class="nav-item dropdown a">
              <a class="nav-link" href="#">Shop</a>
            </li>
	          <li class="nav-item"><a href="index.html#about-us" class="nav-link">About</a></li>
	          <li class="nav-item"><a href="index.html#ContactUs" class="nav-link">Contact</a></li>
	          <li class="nav-item cta cta-colored"><a href="cart.php" class="nav-link"><span class="icon-shopping_cart"></span>[0]</a></li>

	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->

    <section class="container d-block">
    	<div class="row">
    		<div class="col-2">
		    	<div id="sidebar">
		    		<div class="toggle-btn" onclick="toggleSidebar()"><a>
		    			<span></span>
		    			<span></span>
		    			<span></span></a>
		    		</div>
		    		<ul>
		    			<a href="n"></a><li>Clothes</li>
		    			<li>Electronics</li>
		    			<li>Accessories</li>
		    			<li>School</li>
		    			<li>Food</li>
		    		</ul>
		    	</div>
		    </div>
		    <div class="col-10">
		    	<div class="row">
		    		  <?php
					    while ($row = mysqli_fetch_array($result)) {
					    	echo "<div class='col-4 mt-3'>";
				    			echo"<div class='' style='width: 240px; height:250px;'>";
				    				echo"<div class='wrapper'>";
								  		echo "<img src='images/".$row['image']."' class='card-img-top shop-img' alt='...'' >";
								  		echo"<div class='over'>";
								  			echo"<div class='btn_pos' onclick ='printID(this.id);'>";
									  			 echo"<button class='d-inline cart_btn' id = '".$row['productName']."' >+ ADD TO CART</button>";
									    		echo"<button class='d-inline order_btn' id = '".$row['productName']."'>ORDER NOW</button>";
								    		echo"</div>";
								  		echo"</div>";
								  		echo "<h3 class = 'ml-5' 'style= 'font-weight:100; font-family: 'Montserrat', sans-serif;'>".$row['productName']."</h3>";
								  		echo "<span style= 'font-weight:800; font-family: 'Montserrat', sans-serif;' class='ml-5'> GHc ".$row['price']."</span>";
									echo"</div>";
								echo"</div>";
				    		echo"</div>";

					     
					    }
					  ?>
		    		
		    			
						  




<!-- 		    		<div class="col-4 mt-5">
		    			<div class="card" style="width: 15rem;">
						  <img src="..." class="card-img-top" alt="...">
						  <div class="card-body">
						    <h5 class="card-title">Card title</h5>
						    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
						    <a href="#" class="btn btn-primary">Go somewhere</a>
						  </div>
						</div>
		    		</div> -->
		    		
		    	</div>
		    	
		    </div>
	    </div>
	    
    </section>





    
  

  


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/main.js"></script>
  <script type="text/javascript" src="sidebar.js"></script>
  <script type="text/javascript" src="product.js"></script>
  <script
  src="https://code.jquery.com/jquery-3.4.1.min.js"
  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
  crossorigin="anonymous"></script>
  
    
  </body>
</html>