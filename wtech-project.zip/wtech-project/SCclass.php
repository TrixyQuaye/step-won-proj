<?php
use PHPUnit\Framework\Product
require('productclass.php')

/**
 *@author Trixy Quaye
 *@version 1.0
 * 
 */
/**
 * 
 */
class ShoppingCart extends Product
{
	
	//a property to store all products chosen in the cart. Accessible to only this class and its child classes
	protected $products = array();
	// a property to give numeric indexes to products in the array above
	protected $position = 0;
	// a property has an array that will store indexes in use
    protected $ids = array();

	/**
	*@return boolean based on whether or not there are items in the cart
	*
	*/
	public function isCartEmpty(){
		return(empty($this->products));

	}
	/**
	*
	*
	*
	*/

	public function addProduct(Product $products){
		
		$id = $products->getId();
		$this->ids[] = $id;


		if (!$id) throw new Exception('The cart requires items with unique ID values.');
	    // Add or update:
	    if (isset($this->products[$id])) {
	        $this->updateItem($products, $this->products[$products]['qty'] + 1);
	    } else {
	        $this->products[$id] = array('item' => $products, 'qty' => 1);
	    }

	}

	/**
	* Update product in cart method
	*@param product and quantity are arguments
	*@return gets id for products selected and updates the cart with the product
	*/


	public function updateProduct(Product $products, $qty) {
	    // Need the unique item id:
	    $id = $products->getId();
	    // Delete or update accordingly:
	    if ($qty === 0) {
	        $this->deleteItem($products);
	    } elseif ( ($qty > 0) && ($qty != $this->products[$id]['qty'])) {
	        $this->products[$id]['qty'] = $qty;
	    }
    }
    /**
	* Method for deleting product in cart 
	*@param accepts one argument; a product
	*@return deletes a product from the products array
	*/ 

    public function deleteProduct(Product $products) {
	    $id = $products->getId();
	    if (isset($this->products[$id])) {
	            unset($this->products[$id]);
	    }
	    //Using the index of the deleted product to remove id value from ids array
	    $index = array_search($id, $this->ids);
        unset($this->ids[$index]);

        //To prevent unnecessary spaces in the array during iterations of this object, ids array must be recreated with the remaining array values
        $this->ids = array_values($this->ids);

    }
}

    class ShoppingCart implements Iterator, Countable{
	    /**
		*@return the unique number of items in the shopping cart
		*/

		public function count(){
			return count($this->products);
		}

		//Iterator methods
		public function key() {
	    	return $this->position;
		}
		public function next() {
		    $this->position++;
		}
		public function rewind() {
		    $this->position = 0;
		}
		public function valid() {
		    return (isset($this->ids[$this->position]));
		}
		//Here, the current index of the product id is retrieved using the position attribute and ids array
		/**
		*@return the value in $products indexed at that point
		*/
		public function current() {
		    $index = $this->ids[$this->position];
		    return $this->products[$index];
	    } 
    }

	








?>