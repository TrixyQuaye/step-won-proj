  function printID(e)
  {
  	e = e || window.event;
  	e = e.target || e.srcElement;
  	console.log("ID: " + e.id);

  	var product = [];
     var cart = {};
    cart.prodName = e.id;
      console.log(cart);
      $.ajax({
      	url: "validate.php",
      	method: "post",
      	data: cart,
      	success: function(res){
      		console.log(res);
      	}
      })
  }

